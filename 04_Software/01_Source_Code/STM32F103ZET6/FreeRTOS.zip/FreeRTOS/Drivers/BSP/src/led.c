#include "led.h"

/*
 *  函数名：void Led_Init(void)
 *  输入参数：无
 *  输出参数：无
 *  返回值：无
 *  函数作用：初始化LED任务初始化状态
*/
void Led_Init(void)
{
	// GPIO引脚配置由MX_GPIO_Init()函数调用
	
    // 默认LED灭:OFF-灭，ON-亮
    RLED(OFF);
    GLED(OFF);
    BLED(OFF);
}
